#include "game.h"

int main()
{
	InitGame();
	
	return 0;
}